package TollStation;

import java.text.DecimalFormat;
import java.util.Scanner;

public class TollStationTester {

    private static DecimalFormat df2 = new DecimalFormat("#.##");

    public static void main(String[] args) {


        Scanner keyboard = new Scanner(System.in);

        System.out.println("Welcome to this toll station.");

        for (double numberOfBooths = getRandomIntegerBetweenRange(0,10);; numberOfBooths--){
            TollBooth newBooth = new TollBooth();

            for (double numberOfCarsAtStation = getRandomIntegerBetweenRange(0,10);; numberOfCarsAtStation--) {
                Car newCar = new Car();

                System.out.println("What kind of car do you drive gas, hybrid or EV ?");
                String carType = keyboard.nextLine();

                System.out.println("How many axel's does your car have ?");
                int axels = keyboard.nextInt();

                System.out.println("How will you be paying cash, card or Es (Electronic system) ?");
                String paymentType = keyboard.nextLine();

                if (carType.equals("gas")) {
                        double carCost = Car.calculatedGasCost(axels);
                        if (paymentType.equals("cash")){
                            System.out.println("Your car's cost is $"+ df2.format(TollBooth.totalCashCost(carCost)));
                        }else if(paymentType.equals("card")){
                            System.out.println("Your car's cost is $"+ df2.format(TollBooth.totalCardCost(carCost)));
                        }else if(paymentType.equals("Es")){
                            System.out.println("Your car's cost is $"+ df2.format(TollBooth.totalESCost(carCost)));
                        }else{
                            System.out.println("Invalid inout please try again.");
                        }
                } else if (carType.equals("hybrid")) {
                        double carCost = Car.calculatedHybridCost(axels);
                        if (paymentType.equals("cash")){
                            System.out.println("Your car's cost is $"+ df2.format(TollBooth.totalCashCost(carCost)));
                        }else if(paymentType.equals("card")){
                            System.out.println("Your car's cost is $"+ df2.format(TollBooth.totalCardCost(carCost)));
                        }else if(paymentType.equals("Es")){
                            System.out.println("Your car's cost is $"+ df2.format(TollBooth.totalESCost(carCost)));
                        }else {
                            System.out.println("Invalid inout please try again.");
                        }
                } else if (carType.equals("EV")) {
                        double carCost = Car.calculatedEVCost(axels);
                        if (paymentType.equals("cash")){
                            System.out.println("Your car's cost is $"+ df2.format(TollBooth.totalCashCost(carCost)));
                        }else if(paymentType.equals("card")){
                            System.out.println("Your car's cost is $"+ df2.format(TollBooth.totalCardCost(carCost)));
                        }else if(paymentType.equals("Es")){
                            System.out.println("Your car's cost is $"+ df2.format(TollBooth.totalESCost(carCost)));
                        }else{
                            System.out.println("Invalid inout please try again.");
                        }
                } else {
                    System.out.println("Invalid input please try again.");
                }
            }
        }
    }
    public static double getRandomIntegerBetweenRange(double min, double max){
        return (int)(Math.random()*((max-min)+1))+min;

    }
}
